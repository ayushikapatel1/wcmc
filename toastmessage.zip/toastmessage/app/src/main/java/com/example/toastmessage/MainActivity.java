package com.example.toastmessage;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText name,pw;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name=findViewById(R.id.name);
        pw=findViewById(R.id.pw);
        button=findViewById(R.id.button);
        button.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(!name.getText().toString().isEmpty() && !pw.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this,"Welcome",Toast.LENGTH_LONG).show();


                }
                else{
                    Toast.makeText(MainActivity.this,"Please fill the correct details",Toast.LENGTH_SHORT).show();
                }
            }

        });
    }
}
