package com.example.loginpage_pract5;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText name,pw;
    Button login,cancel;
    TextView at;
    TextView t;
    int c=5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name=findViewById(R.id.name);
        pw=findViewById(R.id.pw);
        login=findViewById(R.id.login);
        cancel=findViewById(R.id.cancel);
        at=findViewById(R.id.at);
        t=findViewById(R.id.t);
        at.setVisibility(View.GONE);
        login.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                if(name.getText().toString().equals("admin") && pw.getText().toString().equals("admin")){
                   Toast toast= Toast.makeText(MainActivity.this,"Welcome",Toast.LENGTH_LONG);
                    TextView toastMessage=(TextView) toast.getView().findViewById(android.R.id.message);
                    toastMessage.setBackgroundColor(Color.GREEN);
                    toast.show();



                }
                else{
                  Toast toast1=  Toast.makeText(MainActivity.this,"please fill the correct details",Toast.LENGTH_LONG);
                  TextView toastMessage=(TextView) toast1.getView().findViewById(android.R.id.message);
                  toastMessage.setBackgroundColor(Color.RED);
                  toast1.show();
                    at.setVisibility(View.VISIBLE);
                    c--;
                    at.setText(Integer.toString(c));
                    if(c==0){
                        login.setEnabled(false);
                    }
                }
            }
        });
        cancel.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                finish();
            }
        });

    }
}
